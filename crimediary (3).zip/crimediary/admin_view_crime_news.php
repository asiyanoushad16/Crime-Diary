<?php include 'adminheader.php';

extract($_GET);

if (isset($_GET['pub'])) 
{
	extract($_GET);
	$s="update case_news set status='public' where news_id='$pub'";
	update($s);	
	alert('status updated successfully');
}

if (isset($_GET['pri'])) 
{
	extract($_GET);
	$k="update case_news set status='private' where news_id='$pri'";
	update($k);	
	alert('status updated successfully');	
}

?>

<center>
 <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">	
<form method="post">
	
<h1>View <span>Crime News</span> </h1>

<table class="table" >
	<tr>
		<th>Sl.No</th>
		<th>Crime Name</th>
		<th>Police Officer</th>
		<th>Title</th>
		<th>Description</th>
		<th>Image</th>
		<th>Date & Time</th>
		<th>Status</th>
		<th></th>
	</tr>
	<?php  

		$h="SELECT *,`case_news`.`image`AS iimage FROM `case_news`INNER JOIN `crimes`USING(`crime_id`)inner join `polices`on `polices`.`police_id`=`case_news`.`police_id` where crime_id='$crime_id'  ";
		$req=select($h);
		$slno=1;
		foreach ($req as $key ) 
		{ ?>
	<tr>
		<td><?php echo $slno++ ?></td>
		<td><?php echo $key['crime_title'] ?></td>
		<td><?php echo $key['fname'] ?></td>
		<td><?php echo $key['title'] ?></td>
		<td><?php echo $key['descrition'] ?></td>
		<td><img src="<?php echo $key['iimage'] ?>" width="100"></td>
		<td><?php echo $key['date_time'] ?></td>
		<td><?php echo $key['status'] ?></td>

		<?php  

			if ($key['status']=='private') 
			{ ?>
		<td><a class="btn btn-success" href="?pub=<?php echo $key['news_id'] ?>&crime_id=<?php echo $key['crime_id'] ?>">public</a></td>		
			<?php 
			}
			else
			{ ?>
		<td><a class="btn btn-success" href="?pri=<?php echo $key['news_id'] ?>&crime_id=<?php echo $key['crime_id'] ?>">private</a></td>
			<?php }

		?>   

	</tr>
		<?php }
	?>      
</table>

</form>

  </div>
  </section><!-- End Hero -->

</center>

<?php include 'footer.php' ?>
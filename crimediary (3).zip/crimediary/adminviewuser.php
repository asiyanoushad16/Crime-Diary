<?php include 'adminheader.php' ?>
<center><h1>VIEW USER REGISTERED</h1>
<table>
	
	<tr>
			<th>username</th>
			<th>password</th>
			<th>first_name</th>
			<th>last_name</th>
			<th>house_name</th>
			<th>place</th>
			<th>pincode</th>
			<th>phone</th>
			<th>email</th>
			<th>aadhar_no</th>

		
	</tr>
<?php 
	
$q="select * from users   inner join login  using (login_id)";
$res=select($q);
foreach ($res as $row) { ?>
<tr>
<td><?php echo $row['username'] ?></td>
<td><?php echo $row['password'] ?></td>
<td><?php echo $row['first_name'] ?></td>
<td><?php echo $row['last_name'] ?></td>
<td><?php echo $row['house_name'] ?></td>
<td><?php echo $row['place'] ?></td>
<td><?php echo $row['pincode'] ?></td>
<td><?php echo $row['phone'] ?></td>
<td><?php echo $row['email'] ?></td>
<td><?php echo $row['aadhar_no'] ?></td>
</tr>
<?php
}
 ?>
</table>
</center>
<?php include 'publicfooter.php' ?>
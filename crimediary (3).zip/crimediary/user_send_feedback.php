<?php include 'userheader.php' ;

extract($_GET);
$user_id=$_SESSION['user_id'];

if (isset($_POST['submitbutton'])) 
{
	extract($_POST);
	$h="insert into feedback values(null,'$user_id','$feeddiscription','pending','$datetime')";
	insert($h);
	alert('feedback send successfully');
	return redirect('user_send_feedback.php');
}


?>

<center>

	<!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
	
<form method="post">
	
<h1>Send <span>Feedback</span> </h1>

<table class="table" style="width: 500px;">
	<tr>
		<th>Description</th>
		<td><input type="text" required="" class="form-control" name="feeddiscription"></td>
	</tr>
	<tr>
		<th>Time & Date</th>
		<td><input type="datetime-local" required="" class="form-control" name="datetime"></td>
	</tr>
	<tr>
		<td align="center" colspan="2"><input type="submit" class="btn btn-success" name="submitbutton"></td>
	</tr>
</table>

</form>

 </div>
  </section><!-- End Hero -->

<form method="post">
	
<h1>View Reply</h1>

<table class="table">
	<tr>
		<th>Sl.No</th>
		<th>Feedback</th>
		<th>Date & Time</th>
		<th>Reply</th>
	</tr>
	<?php  

		$f="select * from feedback where user_id='$user_id'";
		$rwq=select($f);
		$slno=1;
		foreach ($rwq as $key ) 
		{ ?>
	<tr>
		<td><?php echo $slno++ ?></td>
		<td><?php echo $key['feed_description'] ?></td>
		<td><?php echo $key['date_time'] ?></td>
		<td><?php echo $key['reply'] ?></td>
	</tr>
		<?php }
	?>         
</table>

</form>



</center>

<?php include 'footer.php' ?>
<?php include 'userheader.php'; 

extract($_GET);

?>

<center>
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">	

<?php 

$d="select * from case_news where crime_id='$crime_id'";
$reqs=select($d);

if ($reqs[0]['status']=='public') 
{ ?>

<form method="post">
	
<h1>View <span>Crime News</span> </h1>

<table class="table">
	<tr>
		<th>Sl.No</th>
		<th>Crime Name</th>
		<th>Title</th>
		<th>Description</th>
		<th>Image</th>
		<th>Date & Time</th>
	</tr>
	<?php  
		$h="SELECT *,`case_news`.`image`AS iimage FROM `case_news`INNER JOIN `crimes`USING(`crime_id`) where crime_id='$crime_id'";
		$req=select($h);
		$slno=1;
		foreach ($req as $key ) 
		{ ?>
	<tr>
		<td><?php echo $slno++ ?></td>
		<td><?php echo $key['crime_title'] ?></td>
		<td><?php echo $key['title'] ?></td>
		<td><?php echo $key['descrition'] ?></td>
		<td><img src="<?php echo $key['iimage'] ?>" width="100"></td>
		<td><?php echo $key['date_time'] ?></td>
		
	</tr>
		<?php }
	?> 
</table>

</form>
	
<?php 
}
else
{ 
  alert('Private details');
  return redirect('user_view_crimes.php');
}

?>  


   </div>
  </section><!-- End Hero -->
</center>

<?php include 'footer.php' ?>
<?php include 'userheader.php' ?>

<center>
	 <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
<form method="post">
	
<h1>View <span>Crime Types</span> </h1>

<table class="table">
	<tr>
		<th>Sl.No</th>
		<th>Crime Type</th>
		<th>Description</th>
	</tr>
	<?php  

		$g="select * from crime_types";
		$res=select($g);
		$slno=1;
		foreach ($res as $key ) 
		{ ?>
	<tr>
		<td><?php echo $slno++ ?></td>
		<td><?php echo $key['crime_type_name'] ?></td>
		<td><?php echo $key['description'] ?></td>
	</tr>	
		<?php }

	?>      
</table>

</form>
  </div>
  </section><!-- End Hero -->
</center>

<?php include 'footer.php' ?>
<?php include 'userheader.php' ?>

<center>
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">	
<form method="post">
	
<h1>View <span>Crimes</span> </h1>

<table class="table">
	<tr>
		<th>Sl.No</th>
		<th>Police Off</th>
		<th>Crime Type</th>
		<th>Crime</th>
		<th>Description</th>
		<th>Crime Occurred</th>
		<th>Crime Reported</th>
		<th>Place</th>
		<th>District</th>
		<th>Image</th>
		<th></th>
		<th></th>
	</tr>
	<?php  

		$f="SELECT * FROM `crime_types`INNER JOIN `crimes`USING(`crime_type_id`)INNER JOIN `polices`USING(`police_id`)";
		$row=select($f);
		$slno=1;
		foreach ($row as $key ) 
		{ ?>
	<tr>
		<td><?php echo $slno++ ?></td>
		<td><?php echo $key['fname'] ?></td>
		<td><?php echo $key['crime_type_name'] ?></td>
		<td><?php echo $key['crime_title'] ?></td>
		<td><?php echo $key['crime_discription'] ?></td>
		<td><?php echo $key['date_time_occurred'] ?></td>
		<td><?php echo $key['date_time_reported'] ?></td>
		<td><?php echo $key['place'] ?></td>
		<td><?php echo $key['district'] ?></td>
		<td><img src="<?php echo $key['image'] ?> " width="200" height="150"></td>
		<td><a class="btn btn-success" href="user_view_criminals.php?crime_id=<?php echo $key['crime_id'] ?>">View Criminals</a></td>
		<td><a class="btn btn-success" href="user_view_crime_news.php?crime_id=<?php echo $key['crime_id'] ?>">View Crime News</a></td>
	</tr>	
		<?php }
	?>        
</table>

</form>

    </div>
  </section><!-- End Hero -->
</center>

<?php include 'footer.php' ?>
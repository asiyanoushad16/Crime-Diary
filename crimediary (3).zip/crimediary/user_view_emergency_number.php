<?php include 'userheader.php' ?>

<center>
<!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">	
<form method="post">
	
<h1>View <span>Emergency Number</span> </h1>

<table class="table" style="width: 500px;">
	<tr>
		<th>Sl.No</th>
		<th>Number</th>
	</tr>
	<?php  

		$k="select * from emergency_number";
		$req=select($k);
		$slno=1;
		foreach ($req as $key ) 
		{ ?>
	<tr>
		<td><?php echo $slno++ ?></td>
		<td><?php echo $key['emergency_num'] ?></td>
	</tr>
		<?php }
	?>     
</table>

</form>
 </div>
  </section><!-- End Hero -->
</center>

<?php include 'footer.php' ?>
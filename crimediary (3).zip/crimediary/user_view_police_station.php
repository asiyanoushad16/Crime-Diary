<?php include 'userheader.php' ?>

<center>
	 <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
<form method="post">
	
<h1>View Police <span> Stations</span></h1>

<table class="table">
	<tr>
		<th>Sl.No</th>
		<th>Station Name</th>
		<th>Place</th>
		<th>Landmark</th>
		<th>Pincode</th>
		<th>Phone</th>
	</tr>
	<?php  

			$j="select * from police_station";
			$rea=select($j);
			$slno=1;
			foreach ($rea as $key ) 
			{ ?>
	<tr>
		<td><?php echo $slno++ ?></td>
		<td><?php echo $key['name'] ?></td>
		<td><?php echo $key['place'] ?></td>
		<td><?php echo $key['landmark'] ?></td>
		<td><?php echo $key['pincode'] ?></td>
		<td><?php echo $key['phone'] ?></td>
	</tr>
			<?php }

	?>  
</table>

</form>
  </div>
  </section><!-- End Hero -->
</center>

<?php include 'footer.php' ?>
<?php include 'userheader.php' ?>

			<center><h1>VIEW EMERGENCY NUMBER</h1>
<table>
	
	<tr>
				<th>name</th>
			<th>phone</th>

		
	</tr>
<?php 

$q="select * from emergency_no";
$res=select($q);
foreach ($res as $row) { ?>

<tr>
<td><?php echo $row['name'] ?></td>
<td><?php echo $row['phone'] ?></td>
</tr>
<?php
}
 ?>
</table>
 <?php include 'publicfooter.php' ?>

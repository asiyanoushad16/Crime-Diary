<?php include 'publicheader.php';

$user_id=$_SESSION['user_id'];

extract($_GET);

if (isset($_POST['submitbutton'])) 
{
  	extract($_POST);
  	$f="select * from users where user_id='$user_id' and aadhar_no='$aadhno'";
  	$resss=select($f);
  	if(sizeof($resss)>0)
  	{
      alert('your aadhar number is verified');
  		alert('login successfull');
  		return redirect('user_home.php');
  	}
  	else
  	{
  			
		alert('you must check your adhaar number');
  	}
  
} 
   


?>



<center>
	  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
<form method="post">
	
<h1>Verify <span> Your Aadhar</span></h1>

<table class="table" style="width: 500px;">
	<tr>
		<th>Aadhar.No</th>
		<td><input type="text" required="" class="form-control" maxlength="12" pattern="[0-9]{12}" name="aadhno"></td>
	</tr>
	<tr>
		<td align="center" colspan="2"><input type="submit" class="btn btn-success" name="submitbutton"></td>
	</tr>
</table>

</form>

  </div>
  </section><!-- End Hero -->

</center>

<?php include 'footer.php' ?>